import java.io.DataInputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	public static void main(String[] args){
		try {
			ServerSocket ss = new ServerSocket(2505);
			Socket s = ss.accept();
			DataInputStream is = new DataInputStream(s.getInputStream());
			String str = (String)is.readUTF();
			System.out.println("message   " + str);
			ss.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
